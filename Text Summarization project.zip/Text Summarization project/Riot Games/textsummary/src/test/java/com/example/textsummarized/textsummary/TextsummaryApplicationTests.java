package com.example.textsummarized.textsummary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TextsummaryApplicationTests {

	@Test
	void contextLoads() {
	}

}
